package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayServlet
 */
public class DisplayServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String pin = (request.getParameter("pincode"));
		System.out.println("pincode:" + pin);
		String tech = (request.getParameter("technology"));
		System.out.println("technology:" + tech);
		
		
		 Map< String,String> hm = new HashMap< String,String>();
		 List<String> jobList = new ArrayList<String>();
		 
		 if(pin.equalsIgnoreCase("110049") && tech.equalsIgnoreCase("java")  ) // DB
			{
			 	hm.put("110049", "Delhi");
				jobList.add("Java Developer");
			}
			if( pin.equalsIgnoreCase("757020") && tech.equalsIgnoreCase("node.js") ) //DB
			{
				hm.put("757020", "Mumbai");
				jobList.add("Node Js");
				jobList.add("Project- 201");
				
			}
			if( pin.equalsIgnoreCase("244411") && tech.equalsIgnoreCase("selenium"))
			{
				hm.put("244411", "Bangalore");
				jobList.add("Selenium");
				jobList.add("Project- 301");
			}
			
			request.setAttribute("jobList", jobList);
			
			//out.print("Technology "+technologyName);
			Set< Map.Entry< String,String> > st = hm.entrySet();    
			  
			out.print("City:");
		       for (Map.Entry< String,String> me:st) 
		       { 
		           System.out.print(me.getKey()+":"); 
		           System.out.println(me.getValue()); 
		       	  out.print( me.getValue());
		       } 
			out.print("<br/>");
		
			out.print("<br/>");
			out.print("Jobs "+jobList);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
