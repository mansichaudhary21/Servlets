package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet1
 */
public class MyServlet1 extends HttpServlet {
	
    //String technologies[] = {"java","selenium","node.js"};
    //String pincodes[] = {"110049","244411","757020","250001"};
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String technology = request.getParameter("technology");
		String pincode = request.getParameter("pincode");

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// Read the paramater from Index page
		
		out.print("Welcome ");  
		if(pincode.length()>=1) {
		out.print("<a href='ResponseServlet?pincode="+pincode+"&&technology="+technology+"'><h3>Search Jobs</h3></a>");
		}
		else {
		out.print("Invalid pincode");
		out.print("<a href='Index.html'><h3>Login Again<h3></a>");
	}
	

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
