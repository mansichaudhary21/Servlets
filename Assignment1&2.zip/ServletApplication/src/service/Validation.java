package service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.User;

public class Validation {
	
	/*
	 * private static Pattern userNamePattern =
	 * Pattern.compile("^[a-zA-Z_-]{3,14}$"); public String validateUser(User u) {
	 * Matcher mtch = userNamePattern.matcher(u.getUserName());
	 * if(!(u.getUserName().length()>3 && mtch.matches())) return
	 * "UserName is invalid."; if((u.getAge()<=18) && (u.getAge()>60)) return
	 * "Age is not valid"; if(!(u.getPassword().equals(u.getReppassword()))) return
	 * "Password Mismatch"; return "Login Successfully"; }
	 */
	//public String getCategory(User u)
	
	public String getCategory(String[] technology)
	{
		
		System.out.println("----- Inside Validate .java ");
		for (String string : technology) {
				System.out.println(string);
		}
		int len = technology.length;
		for(int i=0;i<len;i++)
		{
			System.out.println("----- Inside For ");
			for (String string : technology) {
					System.out.println(string);
			}
			
			if(len==2)
			{
				if(technology[0].equals("Java") && technology[1].equals("Angular"))
				{
					return "Java Full Stack";
				}
				if(technology[0].equals("Python") && technology[1].equals("R"))
				{
					return "AI Project";
				}
			}
			if(len==1)
			{
				if(technology[0].equals("Oracle"))
				{
					return "DBA";
				}
				if(technology[0].equals("Jupiner"))
				{
					return "Network Admin";
				}
			}
			if(len>2)
			{
				return "Select only 1 or 2 options";
			}
		}
		
		
		return "No Project Selected";
	}
}
