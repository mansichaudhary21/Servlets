package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.User;
import service.Validation;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		// reading data from Form
				String userName = request.getParameter("username");
				String password = request.getParameter("password");
				String reppassword = request.getParameter("reppassword");
				String[] technology = request.getParameterValues("technology");
				String gender = request.getParameter("radiobutton");
				String city = request.getParameter("cityname");
				int age = Integer.parseInt(request.getParameter("userage"));
				int exp = Integer.parseInt(request.getParameter("rangeName"));
				
		//Business Operation
				
				User user = new User(userName,password,reppassword,age,technology,city,gender,exp);
				String category = new Validation().getCategory(technology);
		//UI
				
				System.out.println("----- Inside Servlet .java ");
				for (String string : technology) {
					System.out.println(string);
				}
				
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				Pattern userNamePattern = Pattern.compile("[A-Za-z0-9]+");
				if((userName != null) && userNamePattern.matcher(userName).matches() && (age>18 && age<60) && (password.equals(reppassword)))
				{   
						out.println("<html><body>");
						out.println("Name: "+userName+"<br><br>");
						out.println("Age: "+age+"<br><br>");
						out.println("Technologies are:");
						for(int i=0; i<technology.length; i++)
						{
							out.print(technology[i]+",");
						}
						
						out.println("<br><br>City: "+city+"<br><br>");
						out.println("Gender: "+gender+"<br><br>");
						out.println("Work Experience: "+exp+"<br><br>");
						out.println("Project Selected: " + category);
						out.println("</body></html>");						
		        }
		        else
		        {
		           out.println("Username or Password or age incorrect");
		           out.print("Usrname must be atleast 3 characters and no special characters and spaces are allowed.");
		           out.print("Password must matched.");
		           out.print("Age must be greater than 18 or less than 60");
		        }
									
		
	}
				
				
	
	}

