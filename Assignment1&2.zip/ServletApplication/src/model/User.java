package model;

public class User {

	String userName;
	String password;
	String reppassword;
	int age;
	String[] technology;
	String city;
	String gender;
	int workexp;
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(String userName, String password, String reppassword, int age, String technology[], String city,
			String gender, int workexp) {
		super();
		this.userName = userName;
		this.password = password;
		this.reppassword = reppassword;
		this.age = age;
		this.technology = technology;
		this.city = city;
		this.gender = gender;
		this.workexp = workexp;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getReppassword() {
		return reppassword;
	}
	public void setReppassword(String reppassword) {
		this.reppassword = reppassword;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getTechnology() {
		return technology;
	}
	public void setTechnology(String[] technology) {
		this.technology = technology;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getWorkexp() {
		return workexp;
	}
	public void setWorkexp(int workexp) {
		this.workexp = workexp;
	}
	
//	@Override
//	public String toString()
	//{
		//return "UserModel [Name: " + userName +",Age: " + age +" years" + "Technology known: " + technology 
			//					+"City: " +city+"Gender: "+ gender +"Work Experience: "+ workexp + "]";
	//}

}
