package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet1
 */
public class MyServlet1 extends HttpServlet {
	
	 String technologies[] = {"java","selenium","node.js"};
	 String cities[] = {"Delhi","Moradabad","Meerut","Greater Noida"};
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		boolean isFound = false;
		boolean isFoundCity = false;
		
		// Read the paramater from Index page
				String technology = request.getParameter("technology");
				String city = request.getParameter("city");
				System.out.println("---->Inside MyServlet1--->" + city);
				System.out.println("Inside MyServlet1-->" + technology);
				// code to validate city and technology
				
				for(String c: cities)
				{
					if(city.equalsIgnoreCase(c))
					{
						//bind the city with request scope
						request.setAttribute("city", city);
						System.out.println("Inside MyServlet1-->" + technology);
						for (String tech:technologies) {
							if(technology.equalsIgnoreCase(tech))
							{
								// bind the technology with request scope
								request.setAttribute("technology", technology);
								// response.sendRedirect("MyServlet2"); // new req & resp 
							}	
						}
						request.getRequestDispatcher("MyServlet2").forward(request, response);
						isFoundCity = true;
						isFound = true;
						break;
					}
				}//end for
				
				/*System.out.println("-->Inside MyServlet1-->Technology---" + technology);
				for (String tech:technologies) {
					if(technology.equalsIgnoreCase(tech))
					{
						// bind the technology with request scope
						request.setAttribute("technology", technology);
						// response.sendRedirect("MyServlet2"); // new req & resp 
						
						
						request.getRequestDispatcher("MyServlet2").forward(request, response);
						isFound = true;
						break;
					}
				}//end for
				*/
				
				// in case of not validate 
				if(isFound == false || isFoundCity == false)
				{
					out.print("Technology or city Not In The List");
				}
				
				ServletContext context = getServletContext();
				String serverLocation = context.getInitParameter("server-location");
				
				ServletConfig config = getServletConfig();
				String devName = config.getInitParameter("Servlet-Developer-Name");
				
				out.println("<b> From Servlet-Context </b> "+serverLocation);
				out.println("<br/><b> From Servlet-Config </b> "+devName);
				
		
	}

}
