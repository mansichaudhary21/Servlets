package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet3
 */
public class MyServlet3 extends HttpServlet {
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		
		List<String> jobList = (List<String>)request.getAttribute("jobList");
		String technologyName = (String)request.getAttribute("technology");
		String cityName1 = (String)request.getAttribute("city");
		
		out.print("Technology "+technologyName);
		out.print("<br/>");
		out.print("City:" + cityName1);
		out.print("<br/>");
		out.print("Jobs "+jobList);
	
	}

}
