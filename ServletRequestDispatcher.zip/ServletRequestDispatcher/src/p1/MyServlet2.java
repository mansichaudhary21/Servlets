package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet2
 */
public class MyServlet2 extends HttpServlet {
	
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//List<String> cityList = new ArrayList<String>();
		List<String> jobList = new ArrayList<String>();
		
		//City
		String city = (String)request.getAttribute("city");
		System.out.println("servlet 2" + city);
		out.print("<br/> City from Servlet 1" + city);
		System.out.println("-->Inside MyServlet2--" + city);	
		
		//Technology
		String technology = (String)request.getAttribute("technology");
		System.out.println("Inside MyServlet2-->"+ technology);
		System.out.println(" servlet 2 "+technology);
		out.print("<br/> Technology From Servlet 1 "+technology);
		
		if(city.equalsIgnoreCase("Delhi") && technology.equalsIgnoreCase("java")  ) // DB
		{
			jobList.add("Project- 1");
			jobList.add("Project- 101");
			jobList.add("Project- 11");
			jobList.add("Project- 31");
			
		}
		if( city.equalsIgnoreCase("Meerut") && technology.equalsIgnoreCase("node.js") ) //DB
		{
			jobList.add("Project- 2");
			jobList.add("Project- 201");
			
		}
		if( city.equalsIgnoreCase("Moradabad") && technology.equalsIgnoreCase("selenium"))
		{
			jobList.add("Project- 3");
			jobList.add("Project- 301");
		}
		
		request.setAttribute("jobList", jobList);
		
		request.getRequestDispatcher("MyServlet3").forward(request, response);
		
		
		
		
		///=========================================================
		
		ServletContext context = getServletContext();
		String serverLocation = context.getInitParameter("server-location");
		
		ServletConfig config = getServletConfig();
		String devName = config.getInitParameter("Servlet-Developer-Name");
		
		out.println("<b> From Servlet-Context </b> "+serverLocation);
		out.println("<br/><b> From Servlet-Config </b> "+devName);

	}

}
